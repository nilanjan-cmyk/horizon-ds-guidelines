---
name: horizon-ds
description: |
  Master skill for the Horizon Design System. Loads tokens, component map, atomic-design
  classification, and the human-readable Guideline + machine-readable design.md as references.
  Use this skill BEFORE any UI work that touches the WPRemote / BlogVault / MalCare / Airlift
  product family — design, code, audit, or review.
---

# Horizon Design System — master skill

You are operating inside a project that consumes the **Horizon Design System**. Before doing
any design or frontend work:

1. Read the reference docs in this skill's `references/` folder (in order):
   - `Guidelines_Product_Design.md` — human rules: nomenclature, layout grid, spacing scale (multiples of 8 only), tokens, every component's anatomy, accessibility, audit checklist.
   - `design.md` — machine-readable bridge: tokens (DTCG-shaped), component catalog with Figma keys, code mappings for 9 frameworks, atomic-design tier assessment, MCP integration.
   - `horizon-keys.md` — exact `figma_component_key` / `variable_key` / `text_style_key` values for `importComponentByKeyAsync`.
2. Pick the correct sub-skill for your task:
   - **Tokens only** → `horizon-ds-tokens`
   - **Figma → code translation** → `horizon-ds-figma-bridge`
   - **Atomic-design audit** (variable → atom → molecule rules) → `horizon-ds-atomic-audit`

## Core invariants (auto-fail if violated)

- No raw hex / px / rem in any node. Bind a Horizon variable.
- Allowed gutter / padding / gap values: **multiples of 8** (with `2` and `4` as the only sub-8 exceptions). No 12, no 20, no 22.
- Every UI element is a Horizon component instance — never a custom frame mimicking one.
- Every async region has four states: loading (Skeleton), empty, populated, error.
- Light + Dark mode both verified before claiming done.
- Read on the left, act on the right. One primary CTA per page.

## Discovery commands (run these before designing or coding)

| Need | Tool / call |
|---|---|
| List Horizon pages | `figma.root.children` (via `use_figma`) |
| Find a component by name | MCP `search_design_system` with `includeLibraryKeys=[<lk-...>]` |
| Get a Figma frame's spec | MCP `get_design_context(fileKey, nodeId)` |
| Get visual reference | MCP `get_screenshot` → save to `.figma/{nodeId}.png` |
| Resolve a variable's value | MCP `get_variable_defs` |

## Reference quick paths

- Guideline doc → `references/Guidelines_Product_Design.md`
- Bridge doc → `references/design.md`
- Component keys → `references/horizon-keys.md`
