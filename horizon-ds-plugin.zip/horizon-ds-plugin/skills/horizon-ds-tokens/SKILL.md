---
name: horizon-ds-tokens
description: |
  Lightweight token-only context — colors, spacing, radius, typography, effects.
  Loads in seconds; use when you only need to bind values, not pick components.
---

# Horizon DS — tokens

This is the minimum a Horizon-aware build needs. Always prefer Tier 0 (Variables) tokens. Never raw values.

## Color tokens (Mode collection · Light + Dark)

```yaml
surface:
  page-background-content
  page-background-backlight
  header-background
  navigation-background
  card-background
  widget-background
  muted-background
  overlay-background
  border
  destructive-background
  warning-background
  success-background
typography:
  text-primary
  text-secondary
  text-tertiary
  text-white
  text-black
  text-destructive
  text-warning
  text-success
  text-url        # links + focus ring
alpha:    [10, 20, 30, 40, 50, 60, 70, 80, 90]
charts:   [Chart 1, Chart 2, Chart 3, Chart 4, Chart 5]
```

## Spacing scale (gutter / padding / gap / margin)

**Allowed values:** `0, 2, 4, 8, 16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112, 120, 128, 136, 144, 152, 160, 168, 176, 184, 192, 200`.

Token: `spacing_gap/#gap_{n}`. Anything off this list is reserved for component internals — do not reach for it in new layouts.

## Radius

`radius/rounded_{0, 2, 4, 8, 16, 24, 32, 40, 48, 56, 64, 80, 9999}`. Pill = `9999`.

## Typography

Family **Inter**. Naming: `type/{size}/{lh}/{weight}` — e.g. `type/sm/normal/medium`.

| Size | px | LH-tight | LH-normal |
|---|---|---|---|
| xs | 12 | 12 | 16 |
| sm | 14 | 14 | 20 |
| base | 16 | 16 | 24 |
| lg | 18 | 18 | 28 |
| xl | 20 | 20 | 28 |
| 2xl | 24 | 24 | 32 |
| 3xl | 30 | 30 | 36 |
| 4xl/5xl/6xl/7xl | 36 / 48 / 60 / 72 | — | — |

Defaults: Page Title `type/2xl/tight/semibold` · Body `type/sm/normal/regular` · Button `type/sm/tight/medium` · Helper `type/xs/normal/regular`.

## How to apply

- **Figma plugin API:** `importVariableByKeyAsync` → `setBoundVariableForPaint` (the returned paint is NEW — capture and reassign). For text: `importStyleByKeyAsync` + `node.textStyleId = style.id`.
- **Tailwind:** generate config that mirrors these tokens (see design.md §3.4).
- **CSS vars:** `--surface-card-background`, `--text-primary`, etc. — sync command regenerates `tokens.css`.
