---
name: horizon-ds-atomic-audit
description: |
  Audit a Figma node OR a code file against Horizon's atomic-design tier rules
  (Variables → Atoms → Molecules → Organisms → Templates → Pages). Catches "tier inversion"
  — the most common DS drift cause. Output is a structured, prioritized punch list.
---

# Horizon DS — atomic audit

## The tier contract

```
Variables  →  Atoms        : every visible property of an atom is a token reference
Atoms      →  Molecules    : a molecule references atoms by component-key, not raw geometry
Molecules  →  Organisms    : an organism may reference molecules AND atoms, never raw shapes
Organisms  →  Templates    : a template references organisms by name + slot
Templates  →  Pages        : a page fills template slots with real content
```

Composition is **upward only**. Tier inversion (a molecule reaching for primitives or a frame mimicking a Horizon component) is the failure mode this skill catches.

## Inputs

- A Figma URL (will fetch via MCP `get_design_context` + `get_screenshot`), OR
- A code file path (will read directly).

## Six audit questions (run each against every node)

| # | Question | Pass |
|---|---|---|
| 1 | Does this node use raw hex / px / rem? | **No** — all bound to a Tier 0 token |
| 2 | Is this node a published Horizon instance? | Yes (or a documented proposal) |
| 3 | If it composes children, are *all* children of a strictly lower tier? | Yes — never sideways or upward |
| 4 | Does this node expose props at the right intent level? | Organism props describe the *task*; atom props describe the *shape* |
| 5 | Are all four async states present where applicable? | Loading, empty, populated, error |
| 6 | Are Light + Dark modes both verified? | Yes — both pass contrast ≥ 4.5:1 |

## Output format

```markdown
# Atomic Audit Report — <screen / file name>

**Verdict:** ✅ Passes / ⚠️ Needs Work / ❌ Significant Issues
**Confidence:** <0–100 %>

## Findings

| # | Tier | Issue | Node / line | Priority |
|---|---|---|---|---|
| 1 | Atom | Raw hex `#FAFAFA` instead of `surface/card-background` | `1:6545` | 🔴 Critical |
| 2 | Molecule | "Search bar" built from raw rect + text — not Horizon `Search` instance | `2:3120` | 🟠 High |
| 3 | Organism | Modal missing `error` state | `Modal.tsx:82` | 🟡 Medium |

## Tier inversion detected
- Custom toggle inside settings molecule → use `Switch` atom (Horizon page `760:21705`).

## Recommendations (prioritized)
1. …
2. …
```

## Priority key

- 🔴 Critical — library-level or navigation drift (propagates widely)
- 🟠 High — reusable primitive or token violation
- 🟡 Medium — moderate system drift
- ⚪ Low — nit / consistency

## After the audit

- One concrete fix → invoke `fix-design-system-finding`
- Several findings → invoke `apply-design-system` for a screen-wide pass
