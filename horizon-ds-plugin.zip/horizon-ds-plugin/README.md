# Horizon Design System — Claude Code Plugin

A single drop-in plugin that gives any Claude Code project the full Horizon DS toolkit: two agents, three skills, four slash-commands, and the canonical reference docs (Guidelines, design.md, component keys).

## What's inside

```
horizon-ds-plugin/
├── .claude-plugin/
│   └── plugin.json                       # manifest
├── README.md                             # this file
├── agents/
│   ├── atlas.md                          # product-designer agent (Figma)
│   └── sirius.md                         # frontend-designer agent (code)
├── skills/
│   ├── horizon-ds/                       # umbrella skill — load first
│   │   ├── SKILL.md
│   │   └── references/
│   │       ├── Guidelines_Product_Design.md
│   │       ├── design.md
│   │       └── horizon-keys.md
│   ├── horizon-ds-tokens/                # token-only skill (color/spacing/type)
│   │   └── SKILL.md
│   ├── horizon-ds-figma-bridge/          # Figma↔code translation skill
│   │   └── SKILL.md
│   └── horizon-ds-atomic-audit/          # variable→atom→molecule audit skill
│       └── SKILL.md
└── commands/
    ├── horizon-init.md                   # /horizon-init
    ├── horizon-audit.md                  # /horizon-audit
    ├── horizon-build-screen.md           # /horizon-build-screen
    └── horizon-implement.md              # /horizon-implement
```

## Install

### Option A — local install (any Claude Code project)

```bash
# 1. Unzip this bundle
unzip horizon-ds-plugin.zip -d ~/.claude/plugins/

# 2. Restart Claude Code (or reload the project)
# 3. The agents (Atlas, Sirius), skills, and slash-commands appear automatically.
```

### Option B — pin to a specific project

```bash
# from the repo root of your project
mkdir -p .claude
unzip horizon-ds-plugin.zip -d .claude/plugins/
```

### Option C — from this repository

```bash
gh repo clone nilanjan-cmyk/horizon-ds-guidelines
cp -r horizon-ds-guidelines/horizon-ds-plugin ~/.claude/plugins/horizon-ds
```

## What you get after install

### Two agents (auto-invoked by Claude Code)

| Agent | Model | Owns | Auto-invoked when… |
|---|---|---|---|
| **Atlas** | opus | Figma | "design", "audit screen", "build figma frame", "match design system" |
| **Sirius** | opus | Frontend code | "convert design to code", "transpile React → Vue / Swift / Flutter", "wire UI to API" |

### Three skills (invoke via `Skill` tool or auto-load)

| Skill | Use when |
|---|---|
| `horizon-ds` | Default umbrella — loads tokens, components, atomic-design rules in one shot |
| `horizon-ds-tokens` | Lightweight — just colors, spacing, radius, typography (faster context) |
| `horizon-ds-figma-bridge` | Figma URL or YAML spec → code in any of 9 frameworks |
| `horizon-ds-atomic-audit` | Audit a node/screen for tier inversion (variable → atom → molecule rules) |

### Four slash-commands

| Command | What it does |
|---|---|
| `/horizon-init` | Bootstraps a new screen with the right Page template, tokens, and reference layout |
| `/horizon-audit` | Audits the current Figma frame OR the current code file for DS drift |
| `/horizon-build-screen` | Atlas agent build pipeline — brief → Figma frame using only Horizon components |
| `/horizon-implement` | Sirius agent build pipeline — Figma URL → production code in detected framework |

## Required external setup

The plugin assumes:

1. **Figma Dev Mode MCP** is running on `http://127.0.0.1:3845/mcp` (only required for design tasks; code tasks work without it).
2. **Horizon Figma library** is published and shared with your account. File key `UfHICFSU9PJl9OkE84mUk9`.
3. **Anthropic skills** (`figma-use`, `frontend-design`, `audit-design-system`, `apply-design-system`, `rad-spacing`) are available — these ship with Claude Code.

## Source-of-truth files

Always-on context for every agent invocation:

- `skills/horizon-ds/references/Guidelines_Product_Design.md` — human-readable design rules.
- `skills/horizon-ds/references/design.md` — machine-readable token + component bridge.
- `skills/horizon-ds/references/horizon-keys.md` — Figma component / variable / text-style keys for `importComponentByKeyAsync`.

## Versioning

`1.1.0` — adds atomic-design tier classification (Variables → Atoms → Molecules → Organisms → Templates → Pages) to design.md §6.5.
`1.0.0` — initial release with Atlas, Sirius, and three skills.

## License

MIT.

## Public viewer

Latest docs (auto-updates on edit): **https://nilanjan-cmyk.github.io/horizon-ds-guidelines/**
