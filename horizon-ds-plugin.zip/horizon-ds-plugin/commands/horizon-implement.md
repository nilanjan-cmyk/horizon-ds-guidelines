---
description: Sirius pipeline — turn a Figma URL or YAML spec into production code in the detected framework.
argument-hint: [figma-url-or-spec-path] [framework?]
---

# /horizon-implement — Figma → code

Sirius (frontend designer) takes a Figma URL (or a YAML spec) and produces production code.

## Steps

1. Invoke the **Sirius** agent with the URL/path.
2. Sirius runs Workflow A:
   - Skill("/frontend-design") — set the bar
   - Read `/design.md`
   - Skill("/figma-use")
   - Resolve URL → fileKey + nodeId
   - `get_design_context` → YAML spec
   - `get_screenshot` → save to `.figma/{nodeId}.png`
   - Skill("/figma-implement-design") OR `/implement-design`
   - Detect framework from `package.json` / `pubspec.yaml` / `Cargo.toml` (or use `$2`)
   - Generate code minimally (one component at a time, no premature abstraction)
   - Skill("/rad-spacing") · Skill("/apply-design-system") on the output
   - `preview_start` → `preview_screenshot` → diff vs `.figma/*.png`
   - Iterate until perceptual diff < ~3 %
   - Skill("/audit-design-system") · Skill("/ux-copy") · Skill("/design-critique") · Skill("/design-handoff")
3. Reports: files written, placeholders used, deviations.

Argument: `$1` = Figma URL or YAML path; `$2` = optional framework override.
