---
description: Audit a Figma node OR a code file against the Horizon DS atomic-design rules. Returns a prioritized punch list.
argument-hint: [figma-url-or-file-path]
---

# /horizon-audit — atomic-design audit

Use this to check a screen or component for Horizon DS drift.

## Steps

1. Detect input type:
   - URL containing `figma.com` → Figma audit path
   - Local file path → Code audit path
2. Load the `horizon-ds-atomic-audit` skill.
3. Run the six audit questions against every node:
   1. Raw hex / px? → must be tokenized.
   2. Is this a published Horizon instance? → must be (or a documented proposal).
   3. Are children of a strictly lower tier? → must be.
   4. Are props at the right intent level?
   5. Are all four async states present?
   6. Are Light + Dark modes both verified?
4. Output the standard Atomic Audit Report (markdown) with priority bands.
5. Suggest the next skill: `fix-design-system-finding` for one finding, `apply-design-system` for many.

Argument: `$1` = Figma URL or file path.
