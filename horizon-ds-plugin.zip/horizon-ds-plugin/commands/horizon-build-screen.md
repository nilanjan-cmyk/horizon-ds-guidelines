---
description: Atlas pipeline — turn a brief into a Figma frame using only Horizon components.
argument-hint: [brief]
---

# /horizon-build-screen — brief → Figma frame

Atlas (product designer) takes a written brief and produces a Figma frame using only Horizon components.

## Steps

1. Invoke the **Atlas** agent.
2. Atlas reads `/design.md` and `references/Guidelines_Product_Design.md`.
3. Atlas runs Workflow A:
   - Skill("figma-use")
   - Sketch IA in 1 paragraph (page header, sections, primary CTA)
   - `search_design_system` for every component class needed
   - Build top-down: Page → Top Nav → Sidebar → Page Header → Content
   - Bind every fill / stroke / gap / radius via variable bindings
   - Apply text styles via key
   - Final `get_screenshot` at 2x; verify WCAG AA on primary text
4. Returns: `{ frameId, screenshotPath, deviationsFromGuidelines: [] }`

Argument: `$1` = the brief.
